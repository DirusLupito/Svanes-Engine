#pragma once

#include <svanes/network/msg_pipe.hpp>

#include <chrono>
#include <deque>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <vector>

namespace svanes {

/**
 * Identifies a participant consistently across the configured session.
 *
 * FIELDS:
 * - value: The shared peer id. Zero is invalid.
 *
 * Two peer ids compare equal when their values match.
 */
struct PeerId {
    std::uint32_t value = 0;

    bool operator==(const PeerId &) const = default;
};

/**
 * A nonzero identifier shared by every participant in the session.
 */
using SessionId = std::uint64_t;

/**
 * Identifies a payload format defined by the game.
 */
using MessageType = std::uint16_t;

/**
 * Message types at or above this value are reserved for engine systems built on
 * the session. Games use lower values.
 */
inline constexpr MessageType FirstEngineMessageType = 0xFF00;

/**
 * Leaves 31 bytes for the header within a 1200-byte session packet.
 * The 1200-byte max is taken from Gaffer to avoid IP fragmentation.
 * More information can be found below:
 * https://gafferongames.com/post/packet_fragmentation_and_reassembly/
 */
inline constexpr std::size_t MaxSessionPayloadBytes = 1169;

/**
 * Associates a remote peer with a connection in this process.
 *
 * FIELDS:
 * - peer: The remote participant's shared id.
 * - connection: The local transport handle used to reach that peer.
 */
struct PeerConnection {
    PeerId peer;
    ConnectionId connection;
};

/**
 * Supplies the local identity and the fixed set of remote participants.
 *
 * FIELDS:
 * - session: The nonzero session id shared by all participants.
 * - local_peer: This process's peer id, or zero for a process not yet admitted.
 * - remote_peers: Remote peer-to-connection mappings, excluding the local peer.
 *   Must be empty for a process not yet admitted.
 */
struct SessionConfiguration {
    SessionId session;
    PeerId local_peer;
    std::vector<PeerConnection> remote_peers;
};

/**
 * Controls retry timing and the amount of data retained by a session.
 *
 * FIELDS:
 * - retry_interval: Real time between send attempts for an unacknowledged message.
 * - delivery_timeout: Real time from the first send attempt before reporting failure.
 * - max_pending_per_peer: Maximum pending count and outgoing message id span per peer.
 *   Also bounds how far ahead of a missing message incoming ids are accepted.
 * - max_incoming_messages: Maximum game messages waiting for Receive(), across all peers.
 * - max_packets_per_update: Maximum incoming packets processed per Update(), including
 *   acknowledgments and duplicates, before handling outgoing traffic and returning.
 */
struct ReliabilitySettings {
    std::chrono::milliseconds retry_interval{100};
    std::chrono::milliseconds delivery_timeout{5000};
    std::uint32_t max_pending_per_peer = 256;
    std::uint32_t max_incoming_messages = 1024;
    std::uint32_t max_packets_per_update = 1024;
};

/**
 * A game message together with its sender and payload type.
 *
 * FIELDS:
 * - sender: The peer that sent the message.
 * - type: The game-defined message type used to interpret the payload.
 * - payload: The message bytes, without the session header.
 */
struct SessionMessage {
    PeerId sender;
    MessageType type;
    NetworkMessage payload;
};

/**
 * A message outside every reliable stream: a contact packet from any connection,
 * or data from a connection outside the roster, which is left unacknowledged.
 *
 * FIELDS:
 * - connection: The local transport handle the message arrived on.
 * - message: The claimed sender, game type, and payload.
 * - contact: Whether it arrived as a contact packet rather than unacknowledged data.
 */
struct StrangerMessage {
    ConnectionId connection;
    SessionMessage message;
    bool contact;
};

/**
 * Identifies a data message within one sender-to-recipient stream. Zero is invalid.
 */
using MessageId = std::uint64_t;

/**
 * Identifies what a session packet carries.
 * - Data: A game message with an id assigned by its sender.
 * - Acknowledgment: Confirmation that the recipient accepted the given message id.
 * - Contact: An unreliable game message outside every peer's stream, never
 *   acknowledged or deduplicated. Used to talk to peers that are not yet admitted.
 */
enum class SessionPacketKind : std::uint8_t {
    Data = 1,
    Acknowledgment = 2,
    Contact = 3
};

/**
 * The session's wire representation of a game message or acknowledgment.
 *
 * FIELDS:
 * - kind: Whether this packet carries data or acknowledges a data message.
 * - sender: The peer sending this packet, including for acknowledgments. Zero
 *   only on contact packets from a process not yet admitted.
 * - message_id: The data message's id, echoed back by its acknowledgment.
 * - type: The game-defined payload type for data, or zero for acknowledgments.
 * - payload: The game bytes for data, or empty for acknowledgments.
 */
struct SessionPacket {
    SessionPacketKind kind;
    PeerId sender;
    MessageId message_id;
    MessageType type;
    NetworkMessage payload;
};

/**
 * Encodes a data packet or acknowledgment using the portable wire format.
 *
 * @param session The nonzero session id to include.
 * @param packet The packet kind, identities, and optional game payload.
 * @return The complete packet ready for the transport.
 * @throws std::invalid_argument for zero ids, an unknown kind, or an acknowledgment
 * carrying a game type or payload.
 * @throws std::length_error if the payload exceeds MaxSessionPayloadBytes.
 */
NetworkMessage EncodeSessionPacket(SessionId session,
                                   const SessionPacket &packet);

/**
 * Checks the session header and extracts a data packet or acknowledgment.
 *
 * @param session The session id the message must belong to.
 * @param message The complete received bytes to decode.
 * @return The decoded packet. The game still needs to validate data payloads.
 * @throws std::invalid_argument if the header, size, ids, kind, or acknowledgment
 * contents are invalid.
 */
SessionPacket DecodeSessionPacket(SessionId session,
                                  const NetworkMessage &message);

/**
 * Sends and receives game messages through an owned MsgPipe using a configured
 * peer roster. Each participant has a PeerId shared across the session, and 
 * the roster maps remote peers to the local ConnectionIds used to reach them.
 * 
 * Send() retains a packet with its own per-peer message id. Update() transmits
 * it and retries until the destination acknowledges it or delivery times out.
 * Incoming data is checked against the roster, acknowledged, and queued for
 * Receive(). Duplicate packets are acknowledged again but queued only once.
 * Messages are available in arrival order without waiting for missing ids.
 *
 * Retry timing uses a monotonic real-time clock. Call Update() each frame,
 * including while gameplay is paused, on the thread that created the pipe.
 * A delivery timeout stops traffic to that peer and queues one failure report
 * for the game. The roster and already-queued incoming messages are preserved.
 *
 * Data from a connection outside the roster is reported by ReceiveStranger()
 * but not acknowledged, so the stranger keeps retrying. Once the game admits it
 * with AddPeer(), the next retry is acknowledged and delivered normally. Contact
 * packets, sent with SendStranger(), are always reported by ReceiveStranger(),
 * whether or not their connection is in the roster. Packets carrying a
 * different session id, and malformed packets or acknowledgments from outside
 * the roster, are dropped and logged once per connection.
 *
 * A process not yet admitted has local peer id zero and no roster. It can only
 * use SendStranger() and ReceiveStranger(), and its contact packets carry sender
 * zero. Admit() gives it an id, after which AddPeer() builds its roster.
 *
 * The game defines the payload contents and decides how they affect its world.
 * The caller supplies the initial roster when constructing the session.
 */
class NetworkSession {
public:
    /**
     * Takes ownership of a pipe and validates its configured peer mappings.
     *
     * @param pipe The transport whose connection handles appear in the roster.
     * @param configuration The session id, local peer, and remote mappings.
     * @param settings The retry intervals and queue limits.
     * @throws std::invalid_argument for a null pipe, invalid/duplicate mappings,
     * a roster without a local peer, nonpositive limits or intervals, or a
     * timeout shorter than the retry interval.
     */
    NetworkSession(std::unique_ptr<MsgPipe> pipe,
                   SessionConfiguration configuration,
                   ReliabilitySettings settings = {});

    /**
     * Reads the local identity out of the configuration given at construction.
     * A process here is one running instance of a game, so two instances on one
     * machine are two separate peers.
     *
     * @return The peer id representing this process, or zero before admission.
     */
    PeerId LocalPeer() const;

    /**
     * Reports whether the configured local peer id is nonzero. A process is
     * admitted once a member of the session hands it an id through Admit().
     *
     * @return Whether this process has a peer id.
     */
    bool IsAdmitted() const;

    /**
     * Gives a process that was not yet admitted its peer id.
     * @param local_peer The id assigned by the member that admitted it.
     * @throws std::invalid_argument for a zero id.
     * @throws std::logic_error if the process already has an id.
     */
    void Admit(PeerId local_peer);

    /**
     * Borrows the remote roster held in the configuration. Retired entries stay
     * in the span, since their ids remain reserved for the rest of the session.
     *
     * @return Known remote mappings, including retired routes, borrowed from the session
     * until the next AddPeer().
     */
    std::span<const PeerConnection> RemotePeers() const;

    /**
     * Queues a payload for delivery to one peer. Update() handles transmission.
     *
     * @param destination The configured peer to send to.
     * @param type The game-defined payload type.
     * @param payload The bytes to send, up to MaxSessionPayloadBytes.
     * @return Whether the session accepted the message. Returns false for a failed peer
     * or a full send window. Acceptance does not confirm delivery.
     * @throws std::logic_error before admission.
     * @throws std::invalid_argument if the destination is outside the roster.
     * @throws std::length_error if the payload is too large.
     * @throws std::overflow_error if this peer's message ids are exhausted.
     */
    bool Send(PeerId destination, MessageType type,
              const NetworkMessage &payload);

    /**
     * Queues a payload for every configured remote peer after checking that
     * all peers can accept it. A false return queues nothing.
     *
     * @param type The game-defined payload type.
     * @param payload The bytes to send, up to MaxSessionPayloadBytes.
     * @return Whether every peer's queue accepted the message. Returns true for an empty roster.
     * @throws std::logic_error before admission.
     * @throws std::length_error if the payload is too large.
     * @throws std::overflow_error if a peer's message ids are exhausted.
     */
    bool Broadcast(MessageType type, const NetworkMessage &payload);

    /**
     * Processes incoming packets, acknowledgments, outgoing sends, and retries.
     * Reads at most max_packets_per_update packets so incoming traffic cannot
     * indefinitely delay outgoing work or the next game frame.
     * New data is acknowledged only after entering the game-message queue.
     * Expired deliveries mark their peer as failed and queue one failure report.
     * Call each frame, independently of simulation time or pause state.
     * @throws std::invalid_argument for invalid packets from a roster connection, or
     * a roster connection claiming another sender.
     */
    void Update();

    /**
     * Takes the next game message accepted by Update().
     *
     * @param received Receives the sender, game type, and payload when available.
     * @return Whether a queued game message was available.
     */
    bool Receive(SessionMessage &received);

    /**
     * Takes the next peer failure reported by Update(). Each peer is reported once.
     * @param peer Receives the failed peer's id when a report is available.
     * @return Whether a failure report was available.
     */
    bool ReceivePeerFailure(PeerId &peer);

    /**
     * Takes the next contact packet, or data message from a connection outside the roster.
     * A stranger retries unacknowledged data, so one may be reported repeatedly.
     * @param stranger Receives the connection and message when a report is available.
     * @return Whether a report was available.
     */
    bool ReceiveStranger(StrangerMessage &stranger);

    /**
     * Adds a remote peer to the roster, typically a stranger the game admitted.
     * @param peer The new peer's id and the pipe connection used to reach it.
     * A retired peer still holding the connection is released immediately, since
     * a new process now owns that address.
     * @throws std::invalid_argument for a zero or local id, an unknown connection,
     * a peer id already used in this session, or a connection held by an active peer.
     * @throws std::logic_error before admission.
     */
    void AddPeer(PeerConnection peer);

    /**
     * @param connection The connection to look up.
     * @return The active (not retired) roster peer using the connection, if any.
     */
    std::optional<PeerId> ActivePeerAt(ConnectionId connection) const;

    /**
     * Sends one contact packet to any known connection, without retries or
     * acknowledgment. Used to talk with peers before they are admitted.
     * @param connection The destination, such as one reported by ReceiveStranger().
     * @param type The game-defined payload type.
     * @param payload The bytes to send, up to MaxSessionPayloadBytes.
     * @return Whether the transport accepted the datagram, not whether it arrived.
     * @throws std::invalid_argument if the connection is unknown to the pipe.
     * @throws std::length_error if the payload is too large.
     */
    bool SendStranger(ConnectionId connection, MessageType type, const NetworkMessage &payload);

    /**
     * Stops new traffic to a departed peer while draining accepted sends.
     * Late data is acknowledged and discarded so departure retries can finish.
     * After delivery_timeout, once nothing is pending, the peer's connection is
     * released: its packets arrive as strangers again, but its id stays reserved.
     * Retiring an already retired peer has no effect.
     * @param peer The configured remote identity to retire.
     * @throws std::invalid_argument if the peer is not configured.
     */
    void RetirePeer(PeerId peer);

    /** @return Whether every accepted outgoing message has left the retry queues. */
    bool OutgoingDrained() const;


private:
    /**
     * Retains one outgoing packet until its acknowledgment arrives.
     * FIELDS:
     * - packet: Encoded bytes reused for each send attempt.
     * - first_attempt: Time of the first attempt, or empty before transmission.
     * - last_attempt: Time of the most recent attempt, used after first_attempt is set.
     */
    struct PendingMessage {
        NetworkMessage packet;
        std::optional<std::chrono::steady_clock::time_point> first_attempt;
        std::chrono::steady_clock::time_point last_attempt{};
    };

    /**
     * Tracks delivery separately for one entry in the configured remote roster.
     * FIELDS:
     * - next_message_id: Next outgoing id. Zero marks an exhausted sequence.
     * - pending: Outgoing packets indexed by message id.
     * - received_through: Highest incoming id with every preceding id accepted.
     * - received_ahead: Accepted incoming ids above a gap, retained for duplicate checks.
     * - failed: Whether delivery timed out and further traffic is stopped.
     * - retired: Whether new sends and game delivery are disabled after departure.
     * - retired_at: When the peer was retired, used to decide when to release it.
     * - released: Whether the connection no longer identifies this retired peer.
     */
    struct PeerState {
        MessageId next_message_id = 1;
        std::map<MessageId, PendingMessage> pending;
        MessageId received_through = 0;
        std::set<MessageId> received_ahead;
        bool failed = false;
        bool retired = false;
        std::chrono::steady_clock::time_point retired_at{};
        bool released = false;
    };

    /**
     * Finds the unreleased roster entry that uses a connection.
     * @param connection The connection to look up.
     * @return The entry's index, or empty if the connection is outside the roster.
     */
    std::optional<std::size_t> FindConnection(ConnectionId connection) const;

    /**
     * Checks failure status, queue capacity, and distance from the oldest pending id.
     * @param peer The peer state to inspect.
     * @return Whether another outgoing message can be accepted.
     * @throws std::overflow_error if the message id sequence is exhausted.
     */
    bool CanQueue(const PeerState &peer) const;

    /**
     * Stores an encoded packet and advances the peer's outgoing id sequence.
     * @param peer A peer whose send window has already been checked.
     * @param type The game-defined message type.
     * @param payload The game bytes to encode.
     */
    void QueueMessage(PeerState &peer, MessageType type, const NetworkMessage &payload);

    /**
     * Processes a validated packet from a configured peer.
     * @param index The peer's index in the roster and state array.
     * @param packet The packet whose sender has been checked against its connection.
     */
    void ProcessPacket(std::size_t index, SessionPacket packet);

    /**
     * Logs the first packet dropped from a connection. Later drops are silent.
     * @param connection The connection the packet arrived on.
     * @param reason Why its packets are dropped.
     */
    void LogDroppedConnection(ConnectionId connection, const std::string &reason);

    // The owned transport every packet travels through.
    std::unique_ptr<MsgPipe> pipe;

    // The session id, this process's peer id, and the remote roster. AddPeer()
    // and Admit() update it as the session grows.
    SessionConfiguration configuration;

    // The retry intervals and queue limits applied to every peer.
    ReliabilitySettings settings;

    // Delivery state per remote peer, held in the same order as the roster in
    // configuration.remote_peers, so one index addresses both.
    std::vector<PeerState> peers;

    // Game messages accepted by Update(), in arrival order, waiting for
    // Receive() to take them.
    std::deque<SessionMessage> incoming_messages;

    // One report per peer whose delivery timed out, waiting for
    // ReceivePeerFailure(). Each peer is queued at most once.
    std::deque<PeerId> failed_peers;

    // Contact packets and data from outside the roster, waiting for
    // ReceiveStranger().
    std::deque<StrangerMessage> strangers;

    // Connection ids whose first dropped packet has been logged, so that a
    // misbehaving connection is reported once rather than every packet.
    std::set<std::uint32_t> dropped_connections;
};

}
